import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import Home from './Home'; // Import your Home component
import DesignScreens from './DesignScreens'; // Import your DesignScreen component
import Leaderboard from './Leaderboard';
import Globe from './globe';

const Stack = createStackNavigator();

const App: React.FC = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen
          name="Home"
          component={Home}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="Design"
          component={DesignScreens}
          options={{headerShown: false}} // This should hide the header
        />
        <Stack.Screen
          name="Leaderboard"
          component={Leaderboard}
          options={{headerShown: false}} // This should hide the header
        />
        <Stack.Screen
          name="Globe"
          component={Globe}
          options={{headerShown: false}} // This should hide the header
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
export default App;