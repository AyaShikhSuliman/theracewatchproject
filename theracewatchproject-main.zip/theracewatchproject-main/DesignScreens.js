/* eslint-disable prettier/prettier */
import React, {useState, useEffect} from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity} from 'react-native';
import Video from 'react-native-video';
import Sound from 'react-native-sound';
import {check, PERMISSIONS, RESULTS, request} from 'react-native-permissions';


// Audio Control Logic
const useAudio = () => {
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const toggleAudio = () => {
    setIsPlaying(!isPlaying);
  };

  useEffect(() => {
    if (isPlaying) {
      const newSound = new Sound(require('./racing2.wav'), '', error => {
        if (error) {
          console.log('Failed to load the sound', error);
          return;
        }
        newSound.play(success => {
          if (!success) {
            console.log('Play failed due to audio decoding errors');
            newSound.reset();
          }
        });
        setSound(newSound); // Only set sound if `isPlaying` is true
      });
    } else {
      sound?.pause();
    }

    return () => {
      sound?.release();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying]);

  return [isPlaying, toggleAudio];
};


// Permissions Control Logic
const useStoragePermission = () => {
  useEffect(() => {
    check(PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE)
      .then(result => {
        switch (result) {
          case RESULTS.GRANTED:
            console.log('The permission is granted');
            break;
          case RESULTS.DENIED:
            console.log(
              'The permission has not been requested / is denied but requestable',
            );
            request(PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE).then(
              result => {},
            );
            break;
        }
      })
      .catch(error => {});
  }, []);
};

// Random Time Logic
const useRandomTime = () => {
  const generateRandomTime = () => {
    const minutes = Math.floor(Math.random() * (15 - 5 + 1) + 5);
    const seconds = Math.floor(Math.random() * 60);
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(
      2,
      '0',
    )}`;
  };

  const [randomizedTime, setRandomizedTime] = useState(generateRandomTime());

  useEffect(() => {
    setRandomizedTime(generateRandomTime());
  }, []);

  return randomizedTime;
};

// Main Screen Component
const DesignScreens = ({navigation}) => {
  useStoragePermission();
  const randomizedTime = useRandomTime();
  const [isPlaying, toggleAudio] = useAudio(); // Modified here, using racingWav directly inside the hook


  const handlePressImage14 = () => {
    toggleAudio();
  };

  return (
    <View style={styles.container}>
      <Video
        source={require('./background.mp4')}
        style={styles.backgroundVideo}
        muted={true}
        repeat={true}
        resizeMode={'cover'}
        rate={1.0}
        ignoreSilentSwitch={'obey'}
      />

      <View style={{zIndex: 2}}>
        <TouchableOpacity onPress={() => navigation.navigate('Globe')}>
          <Image source={require('./images/bike.png')} style={styles.bike} />
        </TouchableOpacity>
      </View>

      <Image
        source={require('./images/layer1.png')}
        style={styles.overlayImage}
      />

      <Image
        source={require('./images/Unionpng.png')} // make sure the path is correct
        style={styles.unionImage}
      />

<TouchableOpacity onPress={toggleAudio}>
        <Image
          source={
            isPlaying
              ? require('./images/volumeon.png')
              : require('./images/image14.png')
          }
          style={styles.image14}
        />
      </TouchableOpacity>
      <Image
        source={require('./images/Unionpng.png')} // make sure the path is correct
        style={styles.unionImage2}
      />
      <Image
        source={require('./images/Unionpng.png')} // make sure the path is correct
        style={styles.unionImage3}
      />
      <TouchableOpacity
        style={styles.globeTouchable}
        onPress={() => navigation.navigate('Globe')}>
        <Image source={require('./images/globe.png')} style={styles.globe} />
      </TouchableOpacity>
      <View style={styles.content}>
        <View style={styles.upperContent}>
          <View style={styles.horizontalContent}>
            <Text style={styles.largeText }>133w</Text>
            <Image
              source={require('./images/output-onlinepngtools31.png')}
              style={styles.largeImage}
            />
          </View>
          <View style={styles.horizontalContent}>
            <Text style={styles.text}>40rpm</Text>
            <Image
              source={require('./images/image4.png')}
              style={styles.image4}
            />
            <Text style={styles.text}>10bpm</Text>
            <Image
              source={require('./images/image5.png')}
              style={styles.image5}
            />
          </View>
        </View>
        <View style={styles.lowerContent}>
          <View style={styles.textWithImage}>
            <Text style={styles.textLine}>35kmh</Text>
            <Image
              source={require('./images/output-onlinepngtools21.png')}
              style={styles.smallImage}
            />
          </View>
          <View style={styles.textWithImage}>
            <Text style={styles.textLine}>1.8km</Text>
            <Image
              source={require('./images/outputOnlinepngtools11.png')}
              style={styles.smallImage}
            />
          </View>
          <View style={styles.textWithImage}>
            <Text style={styles.textLine}>6m</Text>
            <Image
              source={require('./images/output-onlinepngtools1.png')}
              style={styles.smallImage}
            />
          </View>
        </View>
        {/* Add the bottom.png image at the bottom */}
        <Image
          source={require('./images/bottom.png')}
          style={styles.bottomImage}
        />
        <View style={styles.randomTimeContainer}>
          <Image
            source={require('./images/time.png')}
            style={styles.timeImage}
          />
          <Text style={styles.randomTimeText}>{randomizedTime}</Text>
        </View>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Leaderboard')}>
          <Text style={styles.buttonText}>Finish Race</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

DesignScreens.navigationOptions = {
  headerShown: false,
};

const styles = StyleSheet.create({
  unionImage: {
    width: 60, // dp (or "dip" - device independent pixels) isn't needed in RN. Just use the numerical value
    height: 60,
    position: 'absolute', // absolute positioning
    top: 170, // changed as per your request
  },
  image14: {
    width: 40, // Adjust as per your design
    height: 40, // Adjust as per your design
    right: -13,
    top: 135, // changed as per your request
  },
  unionImage2: {
    width: 60, // dp (or "dip" - device independent pixels) isn't needed in RN. Just use the numerical value
    height: 60,
    position: 'absolute', // absolute positioning
    top: 170, // changed as per your request
    right: 80,
    zIndex: 0,
  },
  bike: {
    width: 40, // Adjust as per your design
    height: 40, // Adjust as per your design
    left: 300,
    top: 173, // changed as per your request
    zIndex: 1,
  },
  unionImage3: {
    width: 60, // dp (or "dip" - device independent pixels) isn't needed in RN. Just use the numerical value
    height: 60,
    position: 'absolute', // absolute positioning
    top: 170, // changed as per your request
    right: 10,
    zIndex: 0,
  },
  globe: {
    width: 35, // Adjust as per your design
    height: 35, // Adjust as per your design
    left: 233,
    top: 98, // changed as per your request
  },
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'black',
  },
  backgroundVideo: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
  overlayImage: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '27%',
    resizeMode: 'cover',
  },
  content: {
    top: -180,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  upperContent: {
    left: -65,
    top: 25,
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginBottom: 20,
  },
  lowerContent: {
    top: -130,
    left: 120,
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginTop: 20,
  },
  largeText: {
    fontSize: 50,
    color: '#EFE153',
    marginRight: 10,
    fontFamily: 'Anybody',
    fontWeight: 'bold',
  },
  largeImage: {
    width: 44,
    height: 44,
  },
  horizontalContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  text: {
    fontSize: 25,
    fontWeight: '500',
    color: '#FFFFFF',
    marginHorizontal: 5,
    fontFamily: 'Anybody',
  },
  image4: {
    width: 30,
    height: 30,
  },
  image5: {
    width: 30,
    height: 26.087,
  },
  textWithImage: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  textLine: {
    fontSize: 25,
    fontFamily: 'Anybody',
    fontWeight: '500',
    color: '#FFFFFF',
    marginRight: 10,
  },
  smallImage: {
    width: 30,
    height: 30,
  },
  button: {
    width: 255,
    height: 44,
    borderRadius: 7,
    backgroundColor: 'rgba(0, 0, 0, 0.55)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: -20, // Adjusted margin for better centering
  },
  buttonText: {
    color: '#FFF',
    fontSize: 20,
    fontFamily: 'Anybody',
    fontWeight: 'bold',
  },
  // Style for the bottom.png image
  bottomImage: {
    width: 614.767, // Adjusted width
    height: 90, // Adjusted height
    top: 250,
    flexShrink: 0, // Added flex-shrink property
  },
  randomTimeContainer: {
    position: 'absolute',
    bottom: -165,
    flexDirection: 'row',
    alignItems: 'center',
  },
  timeImage: {
    width: 30,
    height: 30,
    marginRight: 10,
  },
  randomTimeText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '600',
  },
});

export default DesignScreens;
