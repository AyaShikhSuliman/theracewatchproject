/* eslint-disable prettier/prettier */
import React, {useState} from 'react';
import {useNavigation} from '@react-navigation/native';
import {View, Text, StyleSheet, Image, TouchableOpacity} from 'react-native';

function Home() {
  const navigation = useNavigation();
  const [isButtonVisible, setIsButtonVisible] = useState(false);

  const handleNavigation = () => {
    navigation.navigate('Design');
  };

  const handleImageClick = () => {
    setIsButtonVisible(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.backgroundContainer}>
        <View style={styles.backgroundShape1} />
        <Text style={styles.racesThisWeekText}>Races this week:</Text>

        <View style={styles.bottomImages}>
        <TouchableOpacity onPress={handleImageClick}>
    <Image source={require('./assests/race.png')} style={styles.imageStyle} />
  </TouchableOpacity>
  <View style={styles.bottomImageContainer}>
    <TouchableOpacity onPress={handleImageClick}>
      <Image source={require('./assests/race2.png')} style={styles.imageStyle2} />
    </TouchableOpacity>
  </View>
        </View>

        <View style={styles.dashboardTextContainer}>
          <Text style={styles.dashboardText}>Dashboard</Text>
        </View>

        <View style={styles.seeMoreContainer}>
          <Text style={styles.seeMoreText}>See More -&gt;</Text>
        </View>

        <View style={styles.startRacingContainer}>
          <View style={styles.startRacingBackground} />
          <TouchableOpacity
            onPress={handleNavigation}
            style={[
              styles.button,
              isButtonVisible ? styles.visibleButton : styles.fadedButton,
            ]}>
            <Text style={styles.startRacingText}>Start Racing</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.clickBannerContainer}>
          <View style={styles.clickBannerBackground} />
          <Text style={styles.clickBannerText}>
            Click on a race banner to begin a live race!
          </Text>
          <Image
            source={require('./assests/m.png')}
            style={styles.clickBannerImage}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  imageStyle: {
    top: -30,
    right: -40,
    marginLeft: -30,
    width: 200,  // adjust as needed
    height: 350, // adjust as needed
    resizeMode: 'contain',
  },
  imageStyle2: {
    top: -30,
    right: -40,
    marginLeft: -30,
    width: 200,  // adjust as needed
    height: 310, // adjust as needed
    resizeMode: 'contain',
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#262626', // Assuming a dark background color
  },
  backgroundContainer: {
    width: '100%',
    height: '100%',
    position: 'relative',
  },
  backgroundShape1: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    backgroundColor: 'rgba(0, 0, 0, 0.55)',
    transform: [{rotate: '-180deg'}],
  },
  racesThisWeekText: {
    width: 223,
    height: 30,
    left: -5,
    top: 182,
    position: 'absolute',
    textAlign: 'center',
    color: 'white',
    fontSize: 24,
    fontFamily: 'Anybody',
    fontWeight: '700',
    wordWrap: 'break-word',
  },
  bottomImages: {
    height: 350,
    left: 10,
    top: 230,
    position: 'absolute',
    justifyContent: 'flex-end',
    alignItems: 'center',
    display: 'flex',
    flexDirection: 'row',
    resizeMode: 'contain',
  },
  dashboardTextContainer: {
    width: 249,
    height: 44,
    left: 7,
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dashboardText: {
    color: 'white',
    fontSize: 40,
    fontFamily: 'Anybody',
    fontWeight: '700',
    wordWrap: 'break-word',
    right: 20,
  },
  seeMoreContainer: {
    width: 87,
    height: 16,
    left: 290,
    top: 190,
    position: 'absolute',
    fontSize: 14,
    fontFamily: 'Anybody',
    fontWeight: '500',
  },
  seeMoreText: {
    position: 'absolute',
    color: '#EFE153',
    fontSize: 12,
    fontFamily: 'Red Hat Display',
    fontWeight: '700',
  },
  startRacingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    top: 290,
  },
  button: {
    top: -30,
    backgroundColor: '#EFE153',
    padding: 10,
    paddingHorizontal: 40,
    borderRadius: 5,
  },
  visibleButton: {
    backgroundColor: '#EFE153',
  },
  fadedButton: {
    backgroundColor: '#EFE153AA',
  },
  startRacingText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  clickBannerContainer: {
    width: 352,
    height: 137,
    left: -9,
    top: 50,
    position: 'absolute',
  },
  clickBannerBackground: {
    width: 320,
    height: 97,
    left: 32,
    top: 11,
    position: 'absolute',
    backgroundColor: '#EFE153',
    borderRadius: 20,
  },
  clickBannerText: {
    width: 236,
    height: 75,
    left: 116,
    top: 29,
    position: 'absolute',
    color: 'black',
    fontSize: 20,
    fontFamily: 'Red Hat Display',
    fontWeight: '700',
    wordWrap: 'break-word',
  },
  clickBannerImage: {
    width: 137,
    height: 137,
    left: 0,
    top: 0,
    position: 'absolute',
  },
});

export default Home;
