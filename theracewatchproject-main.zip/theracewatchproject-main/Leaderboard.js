/* eslint-disable prettier/prettier */
import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Image, ScrollView} from 'react-native';
import {useNavigation} from '@react-navigation/native';

// Import Images
import MyStatsImage from './images/Mystats.png';
import OverallImage from './images/overall.png';
import ProImage from './images/pro.png';

const Leaderboard = () => {
  const navigation = useNavigation();
  
  const namesList = [
    'FILIPPO GANNA', 'PRIMOŽ ROGLIČ', 'TOM DUMOULIN', 'ROHAN DENNIS',
    'TONY MARTIN', 'GERAINT THOMAS', 'WOUT VAN AERT', 'MIGUEL ÁNGEL LÓPEZ',
    // ... more names as desired
  ];

  const [activeType, setActiveType] = useState('default');
  const [activeImage, setActiveImage] = useState(MyStatsImage); // Set initial image
  
  // Constructing a list of 20 leaderboard entries
  const leaderboardEntries = Array.from({length: 20}, (_, index) => {
    const randomName = namesList[Math.floor(Math.random() * namesList.length)];
    return `#${index + 1} ${randomName}`;
  });

  const handleButtonType = (type) => {
    setActiveType(type);

    // Swap the image source based on the type
    switch(type) {
      case 'Professional':
        setActiveImage(ProImage);
        break;
      case 'Overall':
        setActiveImage(OverallImage);
        break;
      default :
        setActiveImage(MyStatsImage);
    }
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.closeButton}
        onPress={() => navigation.navigate('Home')}>
        <Text style={styles.closeButtonText}>X</Text>
      </TouchableOpacity>
      <Text style={styles.leaderboardText}>Leaderboards</Text>
      <View style={styles.topHalf}>
        <Image source={activeImage} style={styles.imageStyle} />
      </View>
      <View style={styles.bottomHalf}>
        <View style={styles.buttonsContainer}>
          {['Professional', 'Overall', 'Personal'].map((type) => (
            <TouchableOpacity 
              key={type}
              style={[styles.button, activeType === type && styles.activeButton]}
              onPress={() => handleButtonType(type)}
            >
              <Text style={styles.buttonText}>{type}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <ScrollView>
          {leaderboardEntries.map((entry, index) => (
            <Text key={index} style={styles.dynamicInfo}>{entry}</Text>
          ))}
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  topHalf: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingTop: 40,
  },
  closeButton: {
    position: 'absolute',
    top: 40,
    right: 20,
    zIndex: 1,
  },
  closeButtonText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  leaderboardText: {
    position: 'absolute',
    top: 40,
    left: 15,
    color: 'white',
    fontSize: 24,
    fontFamily: 'Anybody',
    fontWeight: 'bold',
  },
  bottomHalf: {
    flex: 1,
    backgroundColor: '#0B0D0B',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    alignItems: 'flex-start',
    paddingHorizontal: 15,
    paddingTop: 20,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    width: '100%',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#EFE153',
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
    height: 35,
    width: 100,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeButton: {
    backgroundColor: '#B0B04E', // Change as per your design
  },
  buttonText: {
    color: 'white',
    fontSize: 12,
    fontFamily: 'Anybody',
    fontWeight: 'bold',
  },
  imageStyle: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  dynamicInfo: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});

export default Leaderboard;
