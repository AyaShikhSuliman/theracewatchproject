/* eslint-disable prettier/prettier */
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';

// Import Image
import OverallImage from './images/overall.png';

const Globe = () => {
  const navigation = useNavigation();

  const namesList = [
    'FILIPPO GANNA', 'PRIMOŽ ROGLIČ', 'TOM DUMOULIN', 'ROHAN DENNIS',
    'TONY MARTIN', 'GERAINT THOMAS', 'WOUT VAN AERT', 'MIGUEL ÁNGEL LÓPEZ',
    // ... more names as desired
  ];

  // Constructing a list of 20 leaderboard entries
  const leaderboardEntries = Array.from({length: 20}, (_, index) => {
    const randomName = namesList[Math.floor(Math.random() * namesList.length)];
    return `#${index + 1} ${randomName}`;
  });

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.closeButton}
        onPress={() => navigation.navigate('Design')}>
        <Text style={styles.closeButtonText}>X</Text>
      </TouchableOpacity>
      <Text style={styles.leaderboardText}>Leaderboards</Text>
      <View style={styles.topHalf}>
        <Image source={OverallImage} style={styles.imageStyle} />
      </View>
      <View style={styles.bottomHalf}>
        <ScrollView>
          {leaderboardEntries.map((entry, index) => (
            <Text key={index} style={styles.dynamicInfo}>{entry}</Text>
          ))}
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  topHalf: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingTop: 40,
  },
  closeButton: {
    position: 'absolute',
    top: 40,
    right: 20,
    zIndex: 1,
  },
  closeButtonText: {
    color: 'white',
    fontSize: 24,
    fontFamily: 'Anybody',
    fontWeight: 'bold',
  },
  leaderboardText: {
    position: 'absolute',
    top: 40,
    left: 15,
    color: 'white',
    fontSize: 24,
    fontFamily: 'Anybody',
    fontWeight: 'bold',
  },
  bottomHalf: {
    flex: 1,
    backgroundColor: '#0B0D0B',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    alignItems: 'flex-start',
    paddingHorizontal: 15,
    paddingTop: 20,
  },
  imageStyle: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  dynamicInfo: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});

export default Globe;
